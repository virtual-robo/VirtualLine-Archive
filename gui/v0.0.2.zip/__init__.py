from gui import SelectLevel

if __name__ == '__main__':
    SelectLevel()
